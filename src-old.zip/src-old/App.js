import React from 'react';
import Grid from './component/Grid';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Build Snowman</h1>
      <Grid />
    </div>
  );
}

export default App;
