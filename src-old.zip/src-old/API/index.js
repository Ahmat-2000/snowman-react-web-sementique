import { getPlayer, move, getState } from './stardog.js';

// Test de récupération de la cellule du joueur actuel
getPlayer()
  .then((player) => {
    console.log('Current player position:', player);

    // Exemple : Déplacement vers une nouvelle cellule
    const newCell = 'cell85';
    move(newCell)
      .then(() => console.log(`Player moved to ${newCell}`))
      .catch(console.error);
  })
  .catch(console.error);

// Test de récupération de l'état de l'application
getState()
  .then((state) => {
    console.log('Current state of the application:', state);
  })
  .catch(console.error);
getState().then(console.log)
