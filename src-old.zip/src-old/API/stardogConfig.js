export const username = "achrafams"
export const password = "F7UeWCgUd@hQ5g9"
export const endpoint = "https://sd-3745acf0.stardog.cloud:5820"
