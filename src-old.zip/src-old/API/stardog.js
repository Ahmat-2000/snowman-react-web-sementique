import pkgStardog from 'stardog';
import { uriToId } from './utils.js';

import { username, password, endpoint } from './stardogConfig.js';

const { Connection, query } = pkgStardog;

const conn = new Connection({
  username: 'achrafams',
  password: 'F7UeWCgUd@hQ5g9',
  endpoint: 'https://sd-3745acf0.stardog.cloud:5820',
});

//---------------------------------------------------------------
export function getPlayer() {
  const queryString = 'select ?player where { ?player a :CellPlayer }';
  const database = 'snowman';

  return query
    .execute(conn, database, queryString, 'application/sparql-results+json', {
      limit: 10,
      reasoning: true,
      offset: 0,
    })
    .then((res) => {
      if (!res.ok) throw res.statusText;
      return res.body.results.bindings;
    })
    .then((res) => uriToId(res[0].player.value));
}

export function move(destination) {
  const queryString = `
    DELETE { 
        ?oldCellPlayer a :CellPlayer
    }
    INSERT {
        :${destination} a :CellPlayer
    }
    WHERE {
        ?oldCellPlayer a :CellPlayer 
    }  
  `;

  return query
    .execute(conn, 'snowman', queryString)
    .then((res) => {
      if (!res.ok) throw new Error(res.statusText);
      console.log(`Player successfully moved to ${destination}`);
      return res;
    })
    .catch((error) => {
      console.error('Error executing move:', error);
      throw error;
    });
}

export function canMoveSnowman(direction) {
  const queryString = `
    PREFIX : <http://www.kr2022.com/snowman#>
    SELECT ?snowmanCell ?targetCell
    WHERE {
      ?snowmanCell :contains ?snowman .
      ?snowman a :Snowman .
      ?snowmanCell :has${direction} ?targetCell .
      FILTER NOT EXISTS {
        ?targetCell :contains ?occupied .
        ?occupied a :Snowman .
      }
    }
  `;
  return query
    .execute(conn, 'snowman', queryString, 'application/sparql-results+json')
    .then((res) => {
      if (!res.ok) throw new Error(res.statusText);
      return res.body.results.bindings; // Retourne les résultats
    })
    .catch((error) => {
      console.error(`Failed to check if Snowman can move ${direction}:`, error);
      throw error;
    });
}

export function canPushSnowman(direction) {
  const capitalizedDirection = direction.charAt(0).toUpperCase() + direction.slice(1);
  const queryString = `
    PREFIX : <http://www.kr2022.com/snowman#>
    SELECT ?snowman ?targetCell
    WHERE {
      ?player a :CellPlayer .
      ?player :has${capitalizedDirection} ?snowmanCell .
      ?snowmanCell :contains ?snowman .
      ?snowmanCell :has${capitalizedDirection} ?targetCell .
      FILTER NOT EXISTS {
        ?targetCell :contains ?occupied .
        ?occupied a :Snowman .
      }
      FILTER NOT EXISTS {
        ?targetCell a :Wall .  # Exclut les murs
      }
    }
  `;
  return query.execute(conn, 'snowman', queryString, 'application/sparql-results+json')
    .then((res) => {
      console.log('canPushSnowman results:', res.body.results.bindings);
      return res.body.results.bindings;
    });
}

export function getSnowmen() {
  const queryString = `
    PREFIX : <http://www.kr2022.com/snowman#>
    SELECT ?cell ?snowman
    WHERE { 
      ?cell :contains ?snowman .
      ?snowman a :Snowman .
    }
  `;
  return query
    .execute(conn, 'snowman', queryString, 'application/sparql-results+json')
    .then((res) => {
      console.log('Snowmen fetched:', res.body.results.bindings); // 🔍 Log des résultats
      return res.body.results.bindings;
    });
}

export function moveSnowman(snowmanType, targetCell) {
  const queryString = `
    PREFIX : <http://www.kr2022.com/snowman#>
    DELETE {
      ?currentCell :contains ?snowman .
    }
    INSERT {
      :${targetCell} :contains ?snowman .
    }
    WHERE {
      ?currentCell :contains ?snowman .
      ?snowman a :${snowmanType} .
    }
  `;
  return query
    .execute(conn, 'snowman', queryString)
    .then((res) => {
      if (!res.ok) throw new Error(res.statusText);
      console.log(`Snowman of type ${snowmanType} moved to ${targetCell}`);
    })
    .catch((error) => {
      console.error(`Failed to move Snowman ${snowmanType} to ${targetCell}:`, error);
      throw error;
    });
}

export function resetGame() {
  // Supprime les Snowmen et le joueur actuels
  const deleteQuery = `
    PREFIX : <http://www.kr2022.com/snowman#>
    DELETE { 
      ?cell :contains ?snowman .
      ?snowman a :Snowman .
      ?player a :CellPlayer .
    }
    WHERE {
      OPTIONAL {
        ?cell :contains ?snowman .
        ?snowman a :Snowman .
      }
      OPTIONAL {
        ?player a :CellPlayer .
      }
    }
  `;

  // Insère les positions initiales
  const insertQuery = `
    PREFIX : <http://www.kr2022.com/snowman#>
    INSERT DATA { 
      :cell35 a :CellPlayer .

      :cell22 :contains :bigSnowman .
      :bigSnowman a :Snowman .

      :cell53 :contains :littleSnowman .
      :littleSnowman a :Snowman .

      :cell88 :contains :mediumSnowman .
      :mediumSnowman a :Snowman .
    }
  `;

  // Exécute la suppression suivie de l'insertion
  return query.execute(conn, 'snowman', deleteQuery)
    .then((res) => {
      if (!res.ok) throw new Error('Failed to delete existing entities.');
      return query.execute(conn, 'snowman', insertQuery);
    })
    .then((res) => {
      if (!res.ok) throw new Error('Failed to insert initial entities.');
      console.log('Game successfully reset.');
      return res;
    })
    .catch((error) => {
      console.error('Error resetting game:', error);
      throw error;
    });
}

export function getState() {
  const queryString = `
    PREFIX : <http://www.kr2022.com/snowman#>
    SELECT ?player ?north ?south ?east ?west
    WHERE {
      ?player a :CellPlayer .
      OPTIONAL { ?player :hasNorth ?north . }
      OPTIONAL { ?player :hasSouth ?south . }
      OPTIONAL { ?player :hasEast ?east . }
      OPTIONAL { ?player :hasWest ?west . }
    }
  `;
  const database = 'snowman';

  return query
    .execute(conn, database, queryString, 'application/sparql-results+json', {
      reasoning: true
    })
    .then((res) => res.body.results.bindings[0]) 
    .then((data) => {
      const result = {};
      const keys = Object.keys(data);
      const ids = Object.values(data).map((d) => uriToId(d.value));
      ids.forEach((id, index) => {
        if (id in result) result[id] += ' ' + keys[index];
        else result[id] = keys[index];
      });
      return result;
    });
}

export function moveDirection(direction) {
  const capitalizedDirection = direction.charAt(0).toUpperCase() + direction.slice(1);
  const queryString = `
    DELETE { 
      ?oldCellPlayer a :CellPlayer
    }
    INSERT {
      ?newCellPlayer a :CellPlayer
    }
    WHERE {
      ?oldCellPlayer a :CellPlayer .
      ?oldCellPlayer :has${capitalizedDirection} ?newCellPlayer
    }
  `;
  console.log(`Moving player in direction: ${direction}`);
  console.log(`Query: ${queryString}`);
  return query
    .execute(conn, 'snowman', queryString)
    .then((res) => {
      if (!res.ok) throw new Error(res.statusText);
      console.log(`Player successfully moved ${direction}`);
      return res;
    })
    .catch((error) => {
      console.error('Error executing moveDirection:', error);
      throw error;
    });
}
export function canMovePlayer(direction) {
  const capitalizedDirection = direction.charAt(0).toUpperCase() + direction.slice(1);
  const queryString = `
    PREFIX : <http://www.kr2022.com/snowman#>
    SELECT ?targetCell
    WHERE {
      ?player a :CellPlayer .
      ?player :has${capitalizedDirection} ?targetCell .
      FILTER NOT EXISTS {
        ?targetCell a :Wall .
      }
    }
  `;
  return query.execute(conn, 'snowman', queryString, 'application/sparql-results+json')
    .then((res) => {
      console.log('canMovePlayer results:', res.body.results.bindings);
      return res.body.results.bindings;
    })
    .catch((error) => {
      console.error('Erreur dans canMovePlayer:', error);
      throw error;
    });
}

// Nouvelle fonction pour déplacer joueur + Snowman
export function movePlayerAndSnowman(playerCell, snowmanCell, targetCell) {
  const queryString = `
    PREFIX : <http://www.kr2022.com/snowman#>
    DELETE {
      :${playerCell} a :CellPlayer .
      :${snowmanCell} :contains ?snowman .
    }
    INSERT {
      :${snowmanCell} a :CellPlayer .
      :${targetCell} :contains ?snowman .
    }
    WHERE {
      :${snowmanCell} :contains ?snowman .
    }
  `;

  return query.execute(conn, 'snowman', queryString)
    .then((res) => {
      if (!res.ok) throw new Error(res.statusText);
      console.log(`Player and Snowman moved: ${playerCell} -> ${snowmanCell} -> ${targetCell}`);
    })
    .catch((error) => {
      console.error('Failed to move Player and Snowman:', error);
      throw error;
    });
}


