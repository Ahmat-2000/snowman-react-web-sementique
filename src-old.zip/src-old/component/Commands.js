import React from 'react';
import { resetGame } from '../API/stardog';

export default function Commands({ update }) {
  const handleReset = () => {
    resetGame()
      .then(() => {
        console.log('Game reset successfully.');
        update(); // Met à jour l'affichage de la grille après réinitialisation
      })
      .catch((error) => {
        console.error('Failed to reset game:', error);
      });
  };

  return (
    <div className="commands">
      <button onClick={handleReset} className="command-btn reset">
        Recommencer
      </button>
    </div>
  );
}

