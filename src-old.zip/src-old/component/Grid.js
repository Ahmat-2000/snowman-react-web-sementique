import React, { useState, useEffect } from 'react';
import { getState, getSnowmen, resetGame } from '../API/stardog';
import Cell from './Cell';

const SIZE = 10;

export default function Grid() {
  const [types, setTypes] = useState({});
  const [snowmenTypes, setSnowmenTypes] = useState({});

  // Mise à jour des positions du joueur et des Snowmen
  const update = () => {
    getState()
      .then((state) => {
        console.log('Player state updated:', state);
        setTypes(state);
      })
      .catch((error) => console.error('Failed to fetch player state:', error));

    getSnowmen()
      .then((data) => {
        const snowmenCells = {};
        data.forEach((item) => {
          const cellId = item.cell.value.split('#')[1];
          const snowmanType = item.snowman.value.split('#')[1];
          snowmenCells[cellId] = snowmanType;
        });
        console.log('Snowmen updated:', snowmenCells);
        setSnowmenTypes(snowmenCells);
      })
      .catch((error) => console.error('Failed to fetch Snowmen:', error));
  };

  // Réinitialisation du jeu
  const handleReset = () => {
    resetGame()
      .then(() => {
        console.log('Game reset successfully.');
        update(); // Mise à jour des données après la réinitialisation
      })
      .catch((error) => console.error('Failed to reset game:', error));
  };

  // Réinitialiser automatiquement lors du chargement initial
  useEffect(() => {
    resetGame()
      .then(() => {
        console.log('Game automatically reset on page load.');
        update();
      })
      .catch((error) => console.error('Failed to automatically reset game:', error));
  }, []);

  // Création des cellules de la grille
  const cells = Array(SIZE * SIZE)
    .fill()
    .map((_, index) => (
      <Cell
        key={index}
        types={types}
        snowmen={snowmenTypes}
        x={Math.floor(index / SIZE)}
        y={index % SIZE}
        update={update}
      />
    ));

  return (
    <div>
      <button onClick={handleReset} className="reset-button">
        Recommencer
      </button>
      <div className="grid">{cells}</div>
    </div>
  );
}

