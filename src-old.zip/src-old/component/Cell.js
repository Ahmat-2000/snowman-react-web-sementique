import React, { useState, useEffect } from 'react';
import { moveDirection, moveSnowman, canPushSnowman, movePlayerAndSnowman, canMovePlayer} from '../API/stardog';

export default function Cell(props) {
  const [type, setType] = useState('');
  const key = `cell${props.x}${props.y}`;

  useEffect(() => {
    if (key in props.snowmen) {
      setType(props.snowmen[key]);
    } else if (key in props.types) {
      setType(props.types[key]);
    } else {
      setType('');
    }
  }, [props.types, props.snowmen, key]);

const click = () => {
  console.log(`Cell clicked: ${key} of type ${type}`);

  if (['north', 'south', 'east', 'west'].includes(type)) {
  canMovePlayer(type)
    // Déplacement du joueur
    moveDirection(type)
      .then(() => {
        console.log(`Player moved in direction: ${type}`);
        props.update();
      })
      .catch((error) => console.error(`Failed to move player: ${error}`));
  } else if (['bigSnowman', 'mediumSnowman', 'littleSnowman'].includes(type)) {
    console.log(`Snowman cliqué: ${key} de type ${type}`);

    // Déduire la direction en fonction de la position du joueur
    const playerCell = Object.keys(props.types).find((cell) => props.types[cell] === 'player');
    let direction = '';

    if (playerCell === `cell${props.x}${props.y - 1}`) direction = 'east';
    else if (playerCell === `cell${props.x}${props.y + 1}`) direction = 'west';
    else if (playerCell === `cell${props.x - 1}${props.y}`) direction = 'south';
    else if (playerCell === `cell${props.x + 1}${props.y}`) direction = 'north';

    if (!direction) {
      console.log('Impossible de déterminer la direction pour déplacer le Snowman.');
      return;
    }

    // Vérifier si le Snowman peut être déplacé
    canPushSnowman(direction)
      .then((data) => {
        console.log('Résultat de canPushSnowman:', data);

        if (data.length > 0) {
          const targetCell = data[0].targetCell.value.split('#')[1];
          movePlayerAndSnowman(playerCell, key, targetCell)
            .then(() => {
              console.log(`Player et Snowman déplacés: ${playerCell} -> ${key} -> ${targetCell}`);
              props.update();
            })
            .catch((error) => console.error('Erreur lors du déplacement du joueur et du Snowman:', error));
        } else {
          console.log('Impossible de pousser le Snowman dans cette direction.');
        }
      })
      .catch((error) => console.error('Erreur lors de la vérification du mouvement du Snowman:', error));
  }
};


  return (
    <div
      onClick={click}
      className={`cell ${type}`}
      style={{ top: `${props.x * 50}px`, left: `${props.y * 50}px` }}
    />
  );
}

